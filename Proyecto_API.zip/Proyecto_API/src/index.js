
import express from 'express'
import empleadosRutas from './Routes/empleados.js'
const app = express()

app.use(empleadosRutas)


app.listen(3000)
console.log("server runing 3000")
