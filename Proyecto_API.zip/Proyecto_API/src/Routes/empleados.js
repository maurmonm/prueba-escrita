import {json, Router} from 'express'
const router = Router()



router.get('/empleado',(req, res) => res.send('consultando empleado'))
router.post('/emplyees',(req, res) => res.send('Creando empleados'))
router.put('/emplyees',(req, res) => res.send('actualizando empleados'))
router.delete('/emplyees',(req, res) => res.send('eliminando empleados'))

export default router