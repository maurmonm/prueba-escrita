import {createpool} from 'mysql2/promise'
export const pool  = createpool({
    host: 'localhost',
    user: 'root',
    password: '123456',
    port: 3306,
    database: 'aspirante',
});
connection.connect((error) => {
    if (error) {
      console.error('Error al conectarse a la base de datos: ', error);
      return;
    }
    console.log('Conexión exitosa a la base de datos!');
  
    connection.query('SELECT NOMBRE FROM empleado', (error, results) => {
      if (error) {
        console.error('Error al hacer la consulta: ', error);
        return;
      }
  
      console.log('Resultados de la consulta: ');
      console.log(results);
    });
  });
