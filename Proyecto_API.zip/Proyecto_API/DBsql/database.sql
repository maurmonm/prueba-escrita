CREATE DATABASE aspirante ;
-- Seleccionar la base de datos "aspirante" para trabajar en ella
USE aspirante;

-- Crear la tabla "Empleado"
CREATE TABLE Empleado (
  ID INT (10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  FECHA_INGRESO DATE,
  NOMBRE VARCHAR(50),
  SALARIO INT (12)
);

-- Crear la tabla "Solicitud"
CREATE TABLE Solicitud (
  ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  CODIGO VARCHAR(50),
  DESCRIPCION VARCHAR(50),
  RESUMEN VARCHAR(50),
  ID_EMPLEADO INT(12),
  FOREIGN KEY (ID_EMPLEADO) REFERENCES Empleado(ID)
);

